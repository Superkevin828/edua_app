const express = require('express');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '.')));

// In-memory user database
const USERS = {
    'user@gmail.com': {
        password: 'user12345',
        name: 'Test User',
        role: 'user'
    },
    'admin@test.com': {
        password: 'admin123',
        name: 'Admin User',
        role: 'admin'
    },
    'guest@test.com': {
        password: 'guest123',
        name: 'Guest User',
        role: 'guest'
    }
};

// Serve practice page
app.get('/practice-login', (req, res) => {
    res.sendFile(path.join(__dirname, 'test_page.html'));
});

// Login endpoint - NO RATE LIMITING
app.post('/practice-login', (req, res) => {
    const { email, password } = req.body;
    
    // Simulate network delay
    setTimeout(() => {
        const user = USERS[email];
        
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }
        
        if (user.password !== password) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }
        
        // Login successful
        res.status(200).json({
            success: true,
            message: `Welcome, ${user.name}!`,
            user: {
                name: user.name,
                email: email,
                role: user.role
            }
        });
    }, 200); // 200ms delay
});

// Start server
const PORT = 4000;
app.listen(PORT, () => {
    console.log(`Server: http://localhost:${PORT}`);
    console.log(`Login:  http://localhost:${PORT}/practice-login`);
    console.log('\nTest accounts:');
    console.log('  user@gmail.com : user12345');
    console.log('  admin@test.com : admin123');
    console.log('  guest@test.com : guest123');
});
